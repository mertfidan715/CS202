#include "22101734_mert_fidan.h"
#include <iostream>
#include <cmath>

/**
* Title: Algorithm analysis & Sorting
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 1
* Description : This program creates arrays with varying sizes(1000, 5000, 10000, 20000) and fills them with random integers from 0-10.000 . Each sorting function
is tested by these arrays. 3 array types(random, partially increasing, partially decreasing) are created by using partialSort and reverseArray functions.
*/

void sorting::insertionSort(int *arr, const int size, int &compCount, int &moveCount){
    int i;
    int key;
    int j;
    for (i = 1; i < size; i++){
        key = arr[i];
        moveCount++;
        j = i - 1;
        while (j >= 0 && arr[j] > key){
            arr[j + 1] = arr[j];
            moveCount++;
            j--;
            compCount++;
        }
        if(key > arr[j]){
            compCount++;
        }
        arr[j + 1] = key;
        moveCount++;
    }
}

void sorting::bubbleSort(int *arr, const int size, int &compCount, int &moveCount){
    bool sorted = false;
    for (int pass = 1; (pass < size) && !sorted; ++pass) {
        sorted = true;
        for (int index = 0; index < size-pass; ++index) {
            int nextIndex = index + 1;
            compCount++;//if statement inside second loop
            if(arr[index] > arr[nextIndex]){
                swap(arr[index], arr[nextIndex]);
                moveCount += 3;
                sorted = false; // signal exchange
            }
        }
     }
}

void sorting::mergeSort(int *arr, const int size, int &compCount, int &moveCount){
    mergeSort(arr, size, 0, size-1, compCount, moveCount);
}

void sorting::quickSort(int *arr, const int size, int &compCount, int &moveCount){
    quickSort(arr, size, 0, size-1, compCount, moveCount);
}

void sorting::hybridSort(int *arr, const int size, int &compCount, int &moveCount){
    hybridSort(arr, size, 0, size-1, compCount, moveCount);
}

void sorting::hybridSort(int *arr, const int size, int first, int last, int &compCount, int &moveCount){
    int curArraySize = (last - first) + 1;
    int pivotIndex;
    if(curArraySize > 20){
        partition(arr, size, first, last, pivotIndex, compCount, moveCount);
        hybridSort(arr, size, first, pivotIndex-1, compCount, moveCount);
        hybridSort(arr, size, pivotIndex+1, last, compCount, moveCount);
    }
    else{
        bubbleSort(arr, size, compCount, moveCount);
    }
}

void sorting::swap(int &x, int &y){
    int temp = x;
    x = y;
    y = temp;
}

void sorting::mergeSort(int *arr, const int size, int first, int last, int &compCount, int &moveCount){
    compCount++;
    if(first < last){
        int mid = (first + last)/2;
        mergeSort(arr, size, first, mid, compCount, moveCount);
        mergeSort(arr, size, mid+1, last, compCount, moveCount);
        merge(arr, size, first, mid, last, compCount, moveCount);
    }
}

void sorting::merge(int *arr, const int size, int first, int mid, int last, int &compCount, int &moveCount){
    int tempArray[size];
    int first1 = first;
    int last1 = mid;
    int first2 = mid + 1;
    int last2 = last;
    int index = first1;

    for( ; (first1 <= last1) && (first2 <= last2); ++index) {
        if(arr[first1] < arr[first2]) {
            tempArray[index] = arr[first1];
            ++first1;
            moveCount++;
            compCount++;
        }
        else{
            tempArray[index] = arr[first2];
            ++first2;
            moveCount++;
            compCount++;
        }
    }
    for(; first1 <= last1; ++first1, ++index){
        tempArray[index] = arr[first1];
        moveCount++;
    }
    for(; first2 <= last2; ++first2, ++index){
        tempArray[index] = arr[first2];
        moveCount++;
    }
    for(index = first; index <= last; ++index){
        arr[index] = tempArray[index];
        moveCount++;
    }
}

void sorting::partition(int *arr, const int size, int first, int last, int &pivotIndex, int &compCount, int &moveCount){
    int pivot = arr[first];
    int lastS1 = first; // index of last item in S1
    int firstUnknown = first + 1; // index of first item in unknown
// move one item at a time until unknown region is empty
    for( ; firstUnknown <= last; ++firstUnknown){
        compCount++;
        if(arr[firstUnknown] < pivot){ // belongs to S1
            ++lastS1;
            swap(arr[firstUnknown], arr[lastS1]);
            moveCount += 3;
        } // else belongs to S2
    }
    swap(arr[first], arr[lastS1]);
    moveCount+=3;
    pivotIndex = lastS1;
}

void sorting::quickSort(int *arr, const int size, int first, int last, int &compCount, int &moveCount){
    int pivotIndex;
    if(first < last){
        partition(arr, size, first, last, pivotIndex, compCount, moveCount);
        quickSort(arr, size, first, pivotIndex-1, compCount, moveCount);
        quickSort(arr, size, pivotIndex+1, last, compCount, moveCount);
    }
}

void sorting::choosePivot(int *arr, const int size, int first, int last, int &pivotIndex){//chooses the pivot index to be the element that is closest to the mean
    int minElt = arr[first];
    int maxElt = 0;
    for(int i = first; i <= last; i++){
        if(arr[i] <= minElt){
            minElt = arr[i];
        }
        if(arr[i] >= maxElt){
            maxElt = arr[i];
        }
    }
    int mean = maxElt - minElt;
    int minDiff = maxElt;
    for(int i = first; i <= last; i++){
        if(abs(arr[i] - mean) < minDiff){
            minDiff = abs(arr[i] - mean);
            pivotIndex = i;
        }
    }
}

void sorting::partialSort(int *arr, const int size, int first, int last){
    int curArraySize = (last - first) + 1;
    int pivotIndex;
    int compCount;
    int moveCount;
    choosePivot(arr, size, first, last, pivotIndex);
    if(curArraySize > log2(size)){
        partition(arr, size, first, last, pivotIndex, compCount, moveCount);
        partialSort(arr, size, first, pivotIndex-1);
        partialSort(arr, size, pivotIndex+1, last);
    }
}

void sorting::reverseArray(int *arr, const int size){
    int *res = new int[size];
    for(int i = 0; i < size; i++){
        res[i] = arr[(size-1) - i];
    }
    for(int i = 0; i < size; i++){
        arr[i] = res[i];
    }
}
