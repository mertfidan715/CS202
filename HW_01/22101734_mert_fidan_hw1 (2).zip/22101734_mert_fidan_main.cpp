#include <iostream>
#include <ctime>
#include <math.h>
#include <string>
#include "22101734_mert_fidan.h"
using namespace std;

/**
* Title: Algorithm analysis & Sorting
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 1
* Description : This program creates arrays with varying sizes(1000, 5000, 10000, 20000) and fills them with random integers from 0-10.000 . Each sorting function
is tested by these arrays. 3 array types(random, partially increasing, partially decreasing) are created by using partialSort and reverseArray functions.
*/

int main(){
    sorting s;
    //random arrays
    //for insertion sort
    int* arr1 = new int[1000];
    int* arr2 = new int[5000];
    int* arr3 = new int[10000];
    int* arr4 = new int[20000];
    //for bubble sort
    int* arr5 = new int[1000];
    int* arr6 = new int[5000];
    int* arr7 = new int[10000];
    int* arr8 = new int[20000];
    //for merge sort
    int* arr9 = new int[1000];
    int* arr10 = new int[5000];
    int* arr11 = new int[10000];
    int* arr12 = new int[20000];
    //for quick sort
    int* arr13 = new int[1000];
    int* arr14 = new int[5000];
    int* arr15 = new int[10000];
    int* arr16 = new int[20000];
    //for hybrid sort
    int* arr17 = new int[1000];
    int* arr18 = new int[5000];
    int* arr19 = new int[10000];
    int* arr20 = new int[20000];

    //partially ascending arrays
    //for insertion sort
    int* ascArr1 = new int[1000];
    int* ascArr2 = new int[5000];
    int* ascArr3 = new int[10000];
    int* ascArr4 = new int[20000];
    //for bubble sort
    int* ascArr5 = new int[1000];
    int* ascArr6 = new int[5000];
    int* ascArr7 = new int[10000];
    int* ascArr8 = new int[20000];
    //for merge sort
    int* ascArr9 = new int[1000];
    int* ascArr10 = new int[5000];
    int* ascArr11 = new int[10000];
    int* ascArr12 = new int[20000];
    //for quick sort
    int* ascArr13 = new int[1000];
    int* ascArr14 = new int[5000];
    int* ascArr15 = new int[10000];
    int* ascArr16 = new int[20000];
    //for hybrid sort
    int* ascArr17 = new int[1000];
    int* ascArr18 = new int[5000];
    int* ascArr19 = new int[10000];
    int* ascArr20 = new int[20000];

    //partially descending arrays
    //for insertion sort
    int* descArr1 = new int[1000];
    int* descArr2 = new int[5000];
    int* descArr3 = new int[10000];
    int* descArr4 = new int[20000];
    //for bubble sort
    int* descArr5 = new int[1000];
    int* descArr6 = new int[5000];
    int* descArr7 = new int[10000];
    int* descArr8 = new int[20000];
    //for merge sort
    int* descArr9 = new int[1000];
    int* descArr10 = new int[5000];
    int* descArr11 = new int[10000];
    int* descArr12 = new int[20000];
    //for quick sort
    int* descArr13 = new int[1000];
    int* descArr14 = new int[5000];
    int* descArr15 = new int[10000];
    int* descArr16 = new int[20000];
    //for hybrid sort
    int* descArr17 = new int[1000];
    int* descArr18 = new int[5000];
    int* descArr19 = new int[10000];
    int* descArr20 = new int[20000];

    int sizes[] = {1000, 5000, 10000, 20000};
    int** arr = new int*[60];
    arr[0] = arr1;
    arr[1] = arr2;
    arr[2] = arr3;
    arr[3] = arr4;
    arr[4] = arr5;
    arr[5] = arr6;
    arr[6] = arr7;
    arr[7] = arr8;
    arr[8] = arr9;
    arr[9] = arr10;
    arr[10] = arr11;
    arr[11] = arr12;
    arr[12] = arr13;
    arr[13] = arr14;
    arr[14] = arr15;
    arr[15] = arr16;
    arr[16] = arr17;
    arr[17] = arr18;
    arr[18] = arr19;
    arr[19] = arr20;
    arr[20] = ascArr1;
    arr[21] = ascArr2;
    arr[22] = ascArr3;
    arr[23] = ascArr4;
    arr[24] = ascArr5;
    arr[25] = ascArr6;
    arr[26] = ascArr7;
    arr[27] = ascArr8;
    arr[28] = ascArr9;
    arr[29] = ascArr10;
    arr[30] = ascArr11;
    arr[31] = ascArr12;
    arr[32] = ascArr13;
    arr[33] = ascArr14;
    arr[34] = ascArr15;
    arr[35] = ascArr16;
    arr[36] = ascArr17;
    arr[37] = ascArr18;
    arr[38] = ascArr19;
    arr[39] = ascArr20;
    arr[40] = descArr1;
    arr[41] = descArr2;
    arr[42] = descArr3;
    arr[43] = descArr4;
    arr[44] = descArr5;
    arr[45] = descArr6;
    arr[46] = descArr7;
    arr[47] = descArr8;
    arr[48] = descArr9;
    arr[49] = descArr10;
    arr[50] = descArr11;
    arr[51] = descArr12;
    arr[52] = descArr13;
    arr[53] = descArr14;
    arr[54] = descArr15;
    arr[55] = descArr16;
    arr[56] = descArr17;
    arr[57] = descArr18;
    arr[58] = descArr19;
    arr[59] = descArr20;

    for(int i = 0; i < 1000; i++){
        int n = (rand() % 10000);
        arr1[i] = n;
        arr5[i] = n;
        arr9[i] = n;
        arr13[i] = n;
        arr17[i] = n;
    }
    for(int i = 0; i < 5000; i++){
        int n = (rand() % 10000);
        arr2[i] = n;
        arr6[i] = n;
        arr10[i] = n;
        arr14[i] = n;
        arr18[i] = n;
    }
    for(int i = 0; i < 10000; i++){
        int n = (rand() % 10000);
        arr3[i] = n;
        arr7[i] = n;
        arr11[i] = n;
        arr15[i] = n;
        arr19[i] = n;
    }
    for(int i = 0; i < 20000; i++){
        int n = (rand() % 10000);
        arr4[i] = n;
        arr8[i] = n;
        arr12[i] = n;
        arr16[i] = n;
        arr20[i] = n;
    }
    for(int i = 0; i < 1000; i++){
        int n = (rand() % 10000);
        ascArr1[i] = n;
        ascArr5[i] = n;
        ascArr9[i] = n;
        ascArr13[i] = n;
        ascArr17[i] = n;
    }
    for(int i = 0; i < 5000; i++){
        int n = (rand() % 10000);
        ascArr2[i] = n;
        ascArr6[i] = n;
        ascArr10[i] = n;
        ascArr14[i] = n;
        ascArr18[i] = n;
    }
    for(int i = 0; i < 10000; i++){
        int n = (rand() % 10000);
        ascArr3[i] = n;
        ascArr7[i] = n;
        ascArr11[i] = n;
        ascArr15[i] = n;
        ascArr19[i] = n;
    }
    for(int i = 0; i < 20000; i++){
        int n = (rand() % 10000);
        ascArr4[i] = n;
        ascArr8[i] = n;
        ascArr12[i] = n;
        ascArr16[i] = n;
        ascArr20[i] = n;
    }
    for(int i = 0; i < 1000; i++){
        int n = (rand() % 10000);
        descArr1[i] = n;
        descArr5[i] = n;
        descArr9[i] = n;
        descArr13[i] = n;
        descArr17[i] = n;
    }
    for(int i = 0; i < 5000; i++){
        int n = (rand() % 10000);
        descArr2[i] = n;
        descArr6[i] = n;
        descArr10[i] = n;
        descArr14[i] = n;
        descArr18[i] = n;
    }
    for(int i = 0; i < 10000; i++){
        int n = (rand() % 10000);
        descArr3[i] = n;
        descArr7[i] = n;
        descArr11[i] = n;
        descArr15[i] = n;
        descArr19[i] = n;
    }
    for(int i = 0; i < 20000; i++){
        int n = (rand() % 10000);
        descArr4[i] = n;
        descArr8[i] = n;
        descArr12[i] = n;
        descArr16[i] = n;
        descArr20[i] = n;
    }
    {
    s.partialSort(ascArr2, 5000, 0, 4999);
    s.partialSort(ascArr3, 10000, 0, 9999);
    s.partialSort(ascArr4, 20000, 0, 19999);
    s.partialSort(ascArr5, 1000, 0, 999);
    s.partialSort(ascArr6, 5000, 0, 4999);
    s.partialSort(ascArr7, 10000, 0, 9999);
    s.partialSort(ascArr8, 20000, 0, 19999);
    s.partialSort(ascArr9, 1000, 0, 999);
    s.partialSort(ascArr10, 5000, 0, 4999);
    s.partialSort(ascArr11, 10000, 0, 9999);
    s.partialSort(ascArr12, 20000, 0, 19999);
    s.partialSort(ascArr13, 1000, 0, 999);
    s.partialSort(ascArr14, 5000, 0, 4999);
    s.partialSort(ascArr15, 10000, 0, 9999);
    s.partialSort(ascArr16, 20000, 0, 19999);
    s.partialSort(ascArr17, 1000, 0, 999);
    s.partialSort(ascArr18, 5000, 0, 4999);
    s.partialSort(ascArr19, 10000, 0, 9999);
    s.partialSort(ascArr20, 20000, 0, 19999);
    }
    {
    s.partialSort(descArr1, 1000, 0, 999);
    s.reverseArray(descArr1, 1000);
    s.partialSort(descArr2, 5000, 0, 4999);
    s.reverseArray(descArr2, 5000);
    s.partialSort(descArr3, 10000, 0, 9999);
    s.reverseArray(descArr3, 10000);
    s.partialSort(descArr4, 20000, 0, 19999);
    s.reverseArray(descArr4, 20000);
    s.partialSort(descArr5, 1000, 0, 999);
    s.reverseArray(descArr5, 1000);
    s.partialSort(descArr6, 5000, 0, 4999);
    s.reverseArray(descArr6, 5000);
    s.partialSort(descArr7, 10000, 0, 9999);
    s.reverseArray(descArr7, 10000);
    s.partialSort(descArr8, 20000, 0, 19999);
    s.reverseArray(descArr8, 20000);
    s.partialSort(descArr9, 1000, 0, 999);
    s.reverseArray(descArr9, 1000);
    s.partialSort(descArr10, 5000, 0, 4999);
    s.reverseArray(descArr10, 5000);
    s.partialSort(descArr11, 10000, 0, 9999);
    s.reverseArray(descArr11, 10000);
    s.partialSort(descArr12, 20000, 0, 19999);
    s.reverseArray(descArr12, 20000);
    s.partialSort(descArr13, 1000, 0, 999);
    s.reverseArray(descArr13, 1000);
    s.partialSort(descArr14, 5000, 0, 4999);
    s.reverseArray(descArr14, 5000);
    s.partialSort(descArr15, 10000, 0, 9999);
    s.reverseArray(descArr15, 10000);
    s.partialSort(descArr16, 20000, 0, 19999);
    s.reverseArray(descArr16, 20000);
    s.partialSort(descArr17, 1000, 0, 999);
    s.reverseArray(descArr17, 1000);
    s.partialSort(descArr18, 5000, 0, 4999);
    s.reverseArray(descArr18, 5000);
    s.partialSort(descArr19, 10000, 0, 9999);
    s.reverseArray(descArr19, 10000);
    s.partialSort(descArr20, 20000, 0, 19999);
    s.reverseArray(descArr20, 20000);
    }

    string *str = new string[3];
    str[0] = "                                        Part 2-b-1: Performance analysis of random integers array";
    str[1] = "                                        Part 2-b-2: Performance analysis of partially ascending integers array";
    str[2] = "                                        Part 2-b-3: Performance analysis of partially descending integers array";

    for(int q = 0; q < 3; q++){
        std::cout << str[q] << std::endl;
        for(int i = 0 ; i < 4; i++){
            std::cout << "--------------------------------------------------------------------------------------------------------------------------------------" << std::endl << "                            Elapsed time                   Comp. count               Move Count" << std::endl << "Array Size: " << sizes[i] << std::endl;
            {
                double duration;
                clock_t startTime = clock();
                int compCount = 0;
                int moveCount = 0;
                s.insertionSort(arr[i + q*20], sizes[i], compCount, moveCount);
                duration = 1000 * double( clock() - startTime ) / CLOCKS_PER_SEC;
                std::cout << "Insertion Sort              ";
                std::cout.width(31); std::cout << std::left << duration;
                std::cout.width(26);std::cout << std::left << compCount;
                std::cout << std::left << moveCount<< std::endl;
            }
            {
                double duration;
                clock_t startTime = clock();
                int compCount = 0;
                int moveCount = 0;
                s.bubbleSort(arr[4 + i + q*20], sizes[i], compCount, moveCount);
                duration = 1000 * double( clock() - startTime ) / CLOCKS_PER_SEC;
                std::cout << "Bubble Sort                 ";
                std::cout.width(31); std::cout << std::left << duration;
                std::cout.width(26);std::cout << std::left << compCount;
                std::cout << std::left << moveCount<< std::endl;
            }
            {
                double duration;
                clock_t startTime = clock();
                int compCount = 0;
                int moveCount = 0;
                s.mergeSort(arr[8 + i + q*20], sizes[i], compCount, moveCount);
                duration = 1000 * double( clock() - startTime ) / CLOCKS_PER_SEC;
                std::cout << "Merge Sort                  ";
                std::cout.width(31); std::cout << std::left << duration;
                std::cout.width(26);std::cout << std::left << compCount;
                std::cout << std::left << moveCount<< std::endl;
            }
            {
                double duration;
                clock_t startTime = clock();
                int compCount = 0;
                int moveCount = 0;
                s.quickSort(arr[12 + i + q*20], sizes[i], compCount, moveCount);
                duration = 1000 * double( clock() - startTime ) / CLOCKS_PER_SEC;
                std::cout << "Quick Sort                  ";
                std::cout.width(31); std::cout << std::left << duration;
                std::cout.width(26);std::cout << std::left << compCount;
                std::cout << std::left << moveCount<< std::endl;
            }
            {
                double duration;
                clock_t startTime = clock();
                int compCount = 0;
                int moveCount = 0;
                s.hybridSort(arr[16 + i + q*20], sizes[i], compCount, moveCount);
                duration = 1000 * double( clock() - startTime ) / CLOCKS_PER_SEC;
                std::cout << "Hybrid Sort                 ";
                std::cout.width(31); std::cout << std::left << duration;
                std::cout.width(26); std::cout << std::left << compCount;
                std::cout << std::left << moveCount << std::endl;
            }
        }
        std::cout << "--------------------------------------------------------------------------------------------------------------------------------------" << std::endl << std::endl;
    }
    for(int i = 0; i < 60; i++){
        delete[] arr[i];
    }
    delete[] arr;

    return 0;
}
