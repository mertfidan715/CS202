#include <string>

/**
* Title: Algorithm analysis & Sorting
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 1
* Description : This program creates arrays with varying sizes(1000, 5000, 10000, 20000) and fills them with random integers from 0-10.000 . Each sorting function
is tested by these arrays. 3 array types(random, partially increasing, partially decreasing) are created by using partialSort and reverseArray functions.
*/

class sorting{
public:
    void insertionSort(int *arr, const int size, int &compCount, int &moveCount);
    void bubbleSort(int *arr, const int size, int &compCount, int &moveCount);
    void mergeSort(int *arr, const int size, int &compCount, int &moveCount);
    void quickSort(int *arr, const int size, int &compCount, int &moveCount);
    void hybridSort(int *arr, const int size, int &compCount, int &moveCount);
    void partialSort(int *arr, const int size, int first, int last);
    void reverseArray(int *arr, const int size);
private:
    void swap(int &x, int &y);
    void merge(int *arr, const int size, int first, int mid, int last, int &compCount, int &moveCount);
    void mergeSort(int *arr, const int size, int first, int last, int &compCount, int &moveCount);
    void partition(int *arr, const int size, int first, int last, int &pivotIndex, int &compCount, int &moveCount);
    void quickSort(int *arr, const int size, int first, int last, int &compCount, int &moveCount);
    void hybridSort(int *arr, const int size, int first, int last, int &compCount, int &moveCount);
    void choosePivot(int *arr, const int size, int first, int last, int &pivotIndex);
};
