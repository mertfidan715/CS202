#ifndef __NODE_H
#define __NODE_H
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : Node header, this is header for nodes of linked list
*/
template<class ItemType>
class Node{
public:
    Node();
    Node(const ItemType& itemEntry);
    Node(const ItemType& itemEntry, Node<ItemType>* nextPtrEntry);
    void setItem(const ItemType& itemEntry);
    void setNext(Node<ItemType>* nextPtrEntry);
    ItemType getItem() const;
    Node<ItemType>* getNext() const;
    ItemType item;
    Node<ItemType>* nextPtr;
};
#endif // __NODE_H
