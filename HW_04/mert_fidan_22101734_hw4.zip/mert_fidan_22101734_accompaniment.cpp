#include "mert_fidan_22101734_accompaniment.h"
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : Accompaniment class implementation
*/
Accompaniment::Accompaniment(){
    name = "NULL";
}

Accompaniment::Accompaniment(Snack& snackFirst, Snack& snackSecond){
    string name1 = snackFirst.name;
    string name2 = snackSecond.name;
    snack1 = &snackFirst;
    snack2 = &snackSecond;
    if(name1 < name2){
        name = name1 + name2;
    }
    else{
        name = name2 + name1;
    }
    snackFirst.accompaniments->insertItem(snackSecond);
    snackSecond.accompaniments->insertItem(snackFirst);
    firstInSeconds = snackSecond.accompaniments->headPtr;
    secondInFirsts = snackFirst.accompaniments->headPtr;
}

void Accompaniment::deleteAccompaniment(){
    snack1 = nullptr;
    snack2 = nullptr;
    firstInSeconds = nullptr;
    secondInFirsts = nullptr;
    name = "NULL";
}
