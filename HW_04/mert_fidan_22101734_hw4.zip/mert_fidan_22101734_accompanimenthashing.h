#include "mert_fidan_22101734_accompaniment.h"
#include <iostream>
#include <string>
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : AccompanimentHashing header, this class uses quadratic probing for hashing
*/
class AccompanimentHashing{
public:
    AccompanimentHashing();
    void insertItem(Accompaniment& item);
    Accompaniment* retrieveItem(string nameKey);
    bool deleteItem(string nameKey);
    int hashFunction(string nameKey);
    int quadraticProbing(string nameKey, int i);
    Accompaniment hashTable[71];
    int elementNumber;
};
