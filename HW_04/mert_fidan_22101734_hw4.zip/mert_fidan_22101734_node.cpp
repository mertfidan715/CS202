#include "mert_fidan_22101734_node.h"
#include "mert_fidan_22101734_snack.h"
#include "mert_fidan_22101734_accompaniment.h"
#define NULL __null
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : Node class implementation
*/
using namespace std;

template<class ItemType>
Node<ItemType>::Node(){
    nextPtr = nullptr;
}

template<class ItemType>
Node<ItemType>::Node(const ItemType& itemEntry){
    item = itemEntry;
    nextPtr = nullptr;
}

template<class ItemType>
Node<ItemType>::Node(const ItemType& itemEntry, Node<ItemType>* nextPtrEntry){
    item = itemEntry;
    nextPtr = nextPtrEntry;
}

template<class ItemType>
void Node<ItemType>::setItem(const ItemType& itemEntry){
    item = itemEntry;
}

template<class ItemType>
void Node<ItemType>::setNext(Node<ItemType>* nextPtrEntry){
    nextPtr = nextPtrEntry;
}

template<class ItemType>
ItemType Node<ItemType>::getItem() const{
    return item;
}

template<class ItemType>
Node<ItemType>* Node<ItemType>::getNext() const{
    return nextPtr;
}
template class Node<Snack>;
template class Node<Accompaniment>;

