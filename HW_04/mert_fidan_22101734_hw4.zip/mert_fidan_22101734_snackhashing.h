#include "mert_fidan_22101734_snack.h"
#include <iostream>
#include <string>
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : SnackHashing header, this class uses separate chaining(using linked lists) to handle hashing collisions
*/
class SnackHashing{
public:
    SnackHashing();
    void insertItem(Snack& item);
    Snack* retrieveItem(string nameKey);
    void deleteItem(string nameKey);
    int hashFunction(string nameKey);
    LinkedList<Snack> hashTable[11];
    int itemCount;
};
