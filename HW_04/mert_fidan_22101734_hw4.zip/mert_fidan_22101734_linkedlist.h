#ifndef __LINKEDLIST_H
#define __LINKEDLIST_H
#include "mert_fidan_22101734_node.h"
using namespace std;
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : LinkedList header, used for separate chaining and accompaniments of snacks
*/
template<class ItemType>
class LinkedList{
public:
    LinkedList();
    LinkedList(LinkedList<ItemType>& linkedList);
    virtual ~LinkedList();
    bool isEmpty() const;
    int getLength() const;
    void insertItem(ItemType& entry);
    void removeItem(int location);
    void clearList();
    int itemNo = 0;
    Node<ItemType>* headPtr;
private:
    Node<ItemType>* getNodeAt(int location) const;
};
#endif // __LINKEDLIST_H
