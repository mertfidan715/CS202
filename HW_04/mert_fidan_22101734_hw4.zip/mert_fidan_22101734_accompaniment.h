#ifndef __ACCOMPANIMENT_H
#define __ACCOMPANIMENT_H
#include <string>
#include "mert_fidan_22101734_node.h"
#include "mert_fidan_22101734_snack.h"
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : Accompaniment header, with pointers to the snacks it contains
*/
class Accompaniment{
public:
    Accompaniment();
    Accompaniment(Snack& snackFirst, Snack& snackSecond);
    void deleteAccompaniment();
    string name;
    Snack* snack1;
    Snack* snack2;
    Node<Snack>* firstInSeconds;
    Node<Snack>* secondInFirsts;
};
#endif // __ACCOMPANIMENT_H
