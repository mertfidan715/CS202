#include "mert_fidan_22101734_snackhashing.h"
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : SnackHashing class implementation
*/
SnackHashing::SnackHashing(){
    itemCount = 0;
}

void SnackHashing::insertItem(Snack& item){
    int key = hashFunction(item.name);
    hashTable[key].insertItem(item);
    itemCount++;
}

Snack* SnackHashing::retrieveItem(string nameKey){
    int index = hashFunction(nameKey);
    Node<Snack>* curPtr = hashTable[index].headPtr;
    int checkCount = 0;
    while(curPtr != nullptr && checkCount != hashTable[index].itemNo){
        if(curPtr->item.name == nameKey){
            return &(curPtr->item);
        }
        else{
            curPtr = curPtr->nextPtr;
            checkCount++;
        }
    }
    if(checkCount == hashTable[index].itemNo){
        return nullptr;
    }
}

void SnackHashing::deleteItem(string nameKey){
    int index = hashFunction(nameKey);
    int location = 1;
    Node<Snack>* curPtr = hashTable[index].headPtr;
    while(curPtr != nullptr){
        if(curPtr->item.name == nameKey){
            hashTable[index].removeItem(location);
            break;
        }
        else{
            location++;
            curPtr = curPtr->nextPtr;
        }
    }
    itemCount--;
}

int SnackHashing::hashFunction(string nameKey){
    int sum = 0, res = 0;
    for (std::string::iterator iter = nameKey.begin(); iter != nameKey.end(); ++iter){
        sum += int(*iter);
    }
    res = sum % 11;
    return res;
}

