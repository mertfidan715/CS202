#include "mert_fidan_22101734_snack.h"
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : Snack class implementation
*/
Snack::Snack(){
    name = "NULL";
}

Snack::Snack(string name){
    this->name = name;
    accompaniments = new LinkedList<Snack>;
}
