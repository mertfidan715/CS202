#include "mert_fidan_22101734_linkedlist.h"
#include "mert_fidan_22101734_snack.h"
#include "mert_fidan_22101734_accompaniment.h"
#include <iostream>
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : LinkedList class implementation
*/
template<class ItemType>//default ctor
LinkedList<ItemType>::LinkedList(){
    headPtr = nullptr;
    itemNo = 0;
}

template<class ItemType> //copy ctor
LinkedList<ItemType>::LinkedList(LinkedList<ItemType>& original){
    itemNo = original.itemNo;
    Node<ItemType>* origPtr = original.headPtr;
    if(origPtr == nullptr){
        headPtr = nullptr;
    }
    else{
        headPtr = new Node<ItemType>(origPtr->item);
        Node<ItemType>* copiedPtr = headPtr;
        origPtr = origPtr->getNext();
        while(origPtr != nullptr){
            Node<ItemType>* newNodePtr = new Node<ItemType>(origPtr->item);
            copiedPtr->setNext(newNodePtr);
            origPtr = origPtr->nextPtr;
            copiedPtr = copiedPtr->nextPtr;
        }
        copiedPtr->setNext(nullptr);
    }
}

template<class ItemType> //destructor
LinkedList<ItemType>::~LinkedList(){
    clearList();
}

template<class ItemType>
bool LinkedList<ItemType>::isEmpty() const{
    if(itemNo == 0){return true;}
    else {return false;}
}

template<class ItemType>
int LinkedList<ItemType>::getLength() const{
    return itemNo;
}

template<class ItemType>
Node<ItemType>* LinkedList<ItemType>::getNodeAt(int location) const{
    Node<ItemType>* curPtr = headPtr;
    for(int i = 1; i <= itemNo; i++){
        if(location == i){
            return curPtr;
        }
        curPtr = curPtr->nextPtr;
    }
}

template<class ItemType>
void LinkedList<ItemType>::insertItem(ItemType& entry){
    if(headPtr == nullptr){
        Node<ItemType>* newPtr = new Node<ItemType>(entry);
        newPtr->setNext(nullptr);
        headPtr = newPtr;
    }
    else{
        Node<ItemType>* newPtr = new Node<ItemType>(entry);
        newPtr->setNext(headPtr);
        headPtr = newPtr;

    }
    itemNo++;
}

template<class ItemType>
void LinkedList<ItemType>::removeItem(int location){
    Node<ItemType>* curPtr = nullptr;
    if(location == 1){
        curPtr = headPtr;
        headPtr = headPtr->nextPtr;
    }
    else{
        curPtr = getNodeAt(location);
        Node<ItemType>* prevPtr = getNodeAt(location-1);
        prevPtr->setNext(curPtr->nextPtr);
    }
    curPtr->setNext(nullptr);
    delete curPtr;
    curPtr = nullptr;
    itemNo--;
}

template<class ItemType>
void LinkedList<ItemType>::clearList(){
    Node<ItemType>* curPtr = headPtr;
    if(itemNo == 0){
        return;
    }
    else{
        while(curPtr != nullptr){
            curPtr = curPtr->nextPtr;
            removeItem(1);
        }
        itemNo = 0;
    }
}
template class LinkedList<Snack>;
template class LinkedList<Accompaniment>;

