#ifndef __SNACK_H
#define __SNACK_H
#include <string>
#include "mert_fidan_22101734_linkedlist.h"
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : Snack header
*/
class Snack{
public:
    Snack();
    Snack(string name);
    string name;
    LinkedList<Snack>* accompaniments;
};
#endif // __SNACK_H
