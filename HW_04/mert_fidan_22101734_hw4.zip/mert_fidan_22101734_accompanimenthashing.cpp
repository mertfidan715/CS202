#include "mert_fidan_22101734_accompanimenthashing.h"
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : AccompanimentHashing implementation
*/
AccompanimentHashing::AccompanimentHashing(){
    elementNumber = 0;
}

void AccompanimentHashing::insertItem(Accompaniment& item){
    if(elementNumber != 71){
        int index = hashFunction(item.name);
        int i = 0;
        while(hashTable[index].name != "NULL"){
            index = quadraticProbing(item.name, i);
            i++;
        }
        hashTable[index] = item;
        elementNumber++;
    }
}

Accompaniment* AccompanimentHashing::retrieveItem(string nameKey){
    int index = hashFunction(nameKey);
    int i = 0, checkCount = 0;
    while(hashTable[index].name != nameKey && checkCount != 71){
        index = quadraticProbing(nameKey, i);
        i++;
        checkCount++;
    }
    if(checkCount != 71){
        return &(hashTable[index]);
    }
    else{
        return nullptr;
    }
}

bool AccompanimentHashing::deleteItem(string nameKey){
    int index = hashFunction(nameKey);
    int i = 0;
    int checkCount = 0;
    while(hashTable[index].name != nameKey && checkCount != 71){
        index = quadraticProbing(nameKey, i);
        i++;
        checkCount++;
    }
    if(checkCount != 71){
        //delete each other from their accompaniment list
        LinkedList<Snack>* firstAccompaniments = hashTable[index].snack1->accompaniments;
        LinkedList<Snack>* secondAccompaniments = hashTable[index].snack2->accompaniments;
        Node<Snack>* curPtrFirst = firstAccompaniments->headPtr;
        Node<Snack>* curPtrSecond = secondAccompaniments->headPtr;
        int locFirstInSecond = 1, locSecondInFirst = 1;
        while(curPtrFirst != nullptr){
            if((curPtrFirst->item.name) == (hashTable[index].secondInFirsts->item.name)){
                firstAccompaniments->removeItem(locSecondInFirst);
                break;
            }
            else{
                curPtrFirst = curPtrFirst->nextPtr;
                locSecondInFirst++;
            }
        }
        while(curPtrSecond != nullptr){
            if((curPtrSecond->item.name) == (hashTable[index].firstInSeconds->item.name)){
                secondAccompaniments->removeItem(locFirstInSecond);
                break;
            }
            else{
                curPtrSecond = curPtrSecond->nextPtr;
                locFirstInSecond++;
            }
        }
        //delete current accompaniment item from hashTable
        hashTable[index].deleteAccompaniment();
        elementNumber--;
        return true;
    }
    else{
        return false;
    }
}

int AccompanimentHashing::hashFunction(string nameKey){
    int sum = 0, res = 0;
    for (std::string::iterator iter = nameKey.begin(); iter != nameKey.end(); ++iter){
        sum += int(*iter);
    }
    res = sum % 71;
    return res;
}

int AccompanimentHashing::quadraticProbing(string nameKey, int i){
    return (hashFunction(nameKey) + i*i) % 71;
}

