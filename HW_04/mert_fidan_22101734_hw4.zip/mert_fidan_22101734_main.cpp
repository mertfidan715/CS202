#include "mert_fidan_22101734_accompanimenthashing.h"
#include "mert_fidan_22101734_snackhashing.h"
#include <iostream>
#include <string>
/**
* Title: Balanced search trees and hashing
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 4
* Description : main class implementation, in which the input is taken as command-line and instructions take place.
* THE INPUT SHOULD BE GIVEN IN A SINGLE LINE WITH NO QUOTATION MARKS-> Example: ./hw4 S Apple S Chips S Cheese S Crackers C Apple Chips C Cheese Crackers C Crackers Apple C Crackers Chips L Crackers L Chips D Crackers Cheese L Crackers Q Apple Chips Q Cheese Crackers X
*/
int main(int argv, char* argc[]){
    bool terminated = false;
    SnackHashing snackHashing;
    AccompanimentHashing accompanimentHashing;
    int i = 1;
    while(!terminated && i < argv){
         string instr = argc[i];
         if(instr == "X"){ // OUTPUT = Program is terminated when instruction is X
            terminated = true;
            std::cout << "Program terminated" << std::endl;
            i++;
            break;
         }
         else if(instr == "S"){ //OUTPUT = Snack *snackName* is created
            string name = argc[i + 1];
            Snack* newSnack = new Snack(name);
            snackHashing.insertItem(*newSnack);
            std::cout << "Snack '" << newSnack->name << "' created" << std::endl;
            i += 2;
         }
         else if(instr == "C"){ //OUTPUT => If the snacks given in the instruction exist, OUTPUT = *accompanimentName* created
            string name1, name2;                                                  //Else, OUTPUT = nextLine
            name1 = argc[i + 1];
            name2 = argc[i + 2];
            if(name1 != name2){
                Snack* snack1 = snackHashing.retrieveItem(name1);
                Snack* snack2 = snackHashing.retrieveItem(name2);
                if(snack1 != nullptr && snack2 != nullptr){
                    Accompaniment* newAccompaniment = new Accompaniment(*snack1, *snack2);
                    accompanimentHashing.insertItem(*newAccompaniment);
                    std::cout << newAccompaniment->name << " created" << std::endl;
                }
                else{
                    std::cout << std::endl;
                }
            }
            else{
                std::cout << std::endl;
            }
            i += 3;
         }
         else if(instr == "D"){ //OUTPUT => If the snacks given in the instruction exist, OUTPUT = *accompanimentName* deleted
            string name, name1, name2;                                            //Else, OUTPUT = nextLine
            name1 = argc[i + 1];
            name2 = argc[i + 2];
            if(name1 < name2){
                name = name1 + name2;
            }
            else{
                name = name2 + name1;
            }
            bool deleted = accompanimentHashing.deleteItem(name);
            if(deleted){
                std::cout << name << " deleted" << std::endl;
            }
            else{
                std::cout << std::endl;
            }
            i += 3;
         }
         else if(instr == "L"){ // If the snack given in the instruction exists, OUTPUT = Accompaniments of the given snack
            string name = argc[i + 1];                                   //Else, OUTPUT = Snack *snackName* does not exist
            Snack* snack = snackHashing.retrieveItem(name);
            if(snack != nullptr){
                Node<Snack>* curPtr = snack->accompaniments->headPtr;
                while(curPtr != nullptr){
                    std::cout << curPtr->item.name << " ";
                    curPtr = curPtr->nextPtr;
                }
                std::cout << std::endl;
            }
            else{
                std::cout << "Snack " << name << " does not exist" << std::endl;
            }
            i += 2;
         }
         else if(instr == "Q"){ // If the first snack given in the instruction exists but second does not exist, OUTPUT = Snack *secondSnackName* does not exist
            string name1, name2;// If the second snack given in the instruction exists but first does not exist, OUTPUT = Snack *firstSnackName* does not exist
            bool canBeGiven = false;                                                // If neither of them exist, OUTPUT = Snacks *firstSnackName* and *secondSnackName* do not exist
            name1 = argc[i + 1];                                                       // If both of them exist, OUTPUT = YES or NO based on if the second snack can be given with first snack
            name2 = argc[i + 2];
            Snack* snack1 = snackHashing.retrieveItem(name1);
            Snack* snack2 = snackHashing.retrieveItem(name2);
            if(snack1 != nullptr && snack2 != nullptr){
                Node<Snack>* curPtr = snack1->accompaniments->headPtr;
                while(curPtr != nullptr){
                    if(curPtr->item.name == name2){
                        canBeGiven = true;
                    }
                    curPtr = curPtr->nextPtr;
                }
                if(canBeGiven){
                    std::cout << "Yes" << std::endl;
                }
                else{
                    std::cout << "No" << std::endl;
                }
            }
            else{
                if(snack1 == nullptr && snack2 != nullptr){
                    std::cout << "Snack " << name1 << " does not exist" << std::endl;
                }
                else if(snack2 == nullptr && snack1 != nullptr){
                    std::cout << "Snack " << name2 << " does not exist" << std::endl;
                }
                else{
                    std::cout << "Snacks " << name1 << " and " << name2 << " do not exist" << std::endl;
                }
            }
            i += 3;
         }
    }
    return 0;
}

