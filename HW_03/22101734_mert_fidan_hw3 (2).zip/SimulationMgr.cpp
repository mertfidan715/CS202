#include "simulation.h"

/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Simulation Manager class that includes main function
*/


int main(int argc, char* argv[]){
    simulation s(argv[1]);
    s.startSimulation();
    return 0;
}
