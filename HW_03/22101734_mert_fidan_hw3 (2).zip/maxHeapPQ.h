#include "maxHeap.h"

/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Header for Priority Queue class that uses Max Heap
*/

class maxHeapPQ{
public:
    bool pqIsEmpty() const;
    void pqInsert(const int& newItem);
    void pqDelete(int& priorityItem);
    int peekRoot();
private:
    maxHeap h;
};
