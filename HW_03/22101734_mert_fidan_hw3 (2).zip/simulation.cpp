#include <vector>
#include <string>
#include <sstream>
#include <iostream>
#include <fstream>
#include <math.h>
#include "simulation.h"

/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Implementation of simulation class
*/

void simulation::sortCreatures(creature creatures[], int size){
    for(int i = size - 1; i >= 0; i--){
        int maxID = creatures[0].id;
        int maxIndex = 0;
        for(int j = 0; j <= i; j++){
            if(creatures[j].id > maxID){
                maxIndex = j;
            }
        }
        creature temp = creatures[i];
        creatures[i] = creatures[maxIndex];
        creatures[maxIndex] = temp;
    }
}

simulation::simulation(string inputFileName){
    deadCreatureCount = 0;
    ifstream myfile;
    myfile.open(inputFileName.c_str(), ios_base::in);
    string full;
    vector<string> data;
    int creatureID, creatureHealth;
    double creatureX, creatureY;
    int foodID, foodPriorityValue, foodTime;
    double foodX, foodY;
    if(myfile.is_open()){
        string count;
        getline(myfile, count);
        creatureCount = stoi(count);
        int i = 0;
        while((i < creatureCount) && getline(myfile, full, '\n')){
            stringstream X(full);
            string T;
            while(getline(X, T, ',')){
                data.push_back(T);
            }
            creatureID = stoi(data.at(0));
            creatureIDs.pqInsert(creatureID);
            creatureX = stod(data.at(1));
            creatureY = stod(data.at(2));
            creatureHealth = stoi(data.at(3));
            creature newCreature(creatureID, creatureX, creatureY, creatureHealth);
            newCreature.setVelocity();
            creatures[i] = newCreature;
            i++;
            data.clear();
        }
        sortCreatures(creatures, creatureCount);
        while(getline(myfile, full, '\n')){
            stringstream X(full);
            string T;
            while(getline(X, T, ',')){
                data.push_back(T);
            }
            foodID = stoi(data.at(0));
            foodX = stod(data.at(1));
            foodY = stod(data.at(2));
            foodPriorityValue = stoi(data.at(3));
            foodTime = stoi(data.at(4));
            foodSpawnTime.pqInsert(foodTime);
            food newFood(foodID, foodX, foodY, foodPriorityValue, foodTime);
            foods[foodCount] = newFood;
            foodCount++;
            data.clear();
        }
    }
    myfile.close();
}

void simulation::startSimulation(){
    int timeTick = 0;
    while(deadCreatureCount < creatureCount){
        for(int i = 0; i < creatureCount; i++){
            std::cout << "Creature " << creatures[i].id << ": ";
            printf("%.2f, %.2f", creatures[i].x, creatures[i].y);
            std::cout << std::endl;
        }
        //start food adding phase
        int currentSpawnTimeRoot = foodSpawnTime.peekRoot();
        while(currentSpawnTimeRoot == timeTick && foodSpawnTime.pqIsEmpty() == false){
            for(int i = 0; i < foodCount; i++){
                if((foods[i].spawnTime == foodSpawnTime.peekRoot()) && (foods[i].isAdded == false)){ //adding first food with the same spawn time as the current time tick
                    int spawnTime;
                    foodSpawnTime.pqDelete(spawnTime);
                    int quality = foods[i].quality;
                    foodQuality.pqInsert(quality);
                    foods[i].isAdded = true;
                    currentFoodCount++;
                    break;
                }
            }
            currentSpawnTimeRoot = foodSpawnTime.peekRoot();
        }
        //end food adding phase
        //start fight phase
        int fightIndex = 0;
        while(fightIndex < creatureCount){
            if(creatures[fightIndex].isAlive == false){ //if current creature is dead, skip it
                fightIndex++;
                continue;
            }
            else{ //if current creature is not dead
                int currentCreatureHealth = creatures[fightIndex].health;
                for(int i = 0; i < creatureCount; i++){
                    if((i != fightIndex) && (creatures[i].isAlive != false)){
                        double distance = sqrt(pow(abs(creatures[fightIndex].x - creatures[i].x), 2.0) + pow(abs(creatures[fightIndex].y - creatures[i].y), 2.0));
                        if(distance < 2.0){
                            int secondCreatureHealth = creatures[i].health;
                            if(currentCreatureHealth >= secondCreatureHealth){
                                creatures[i].health = 0;
                                creatures[i].isAlive = false;
                                deadCreatureCount++;
                            }
                        }
                    }
                }
                fightIndex++;
            }
        }
        //end fight phase
        //start food consumption phase
        food preferredFood;
        for(int i = 0; i < creatureCount; i++){
            if(currentFoodCount != 0){
                int preferredFoodIndex = 0;
                for(int i = 0; i < foodCount; i++){
                    if((foods[i].isEaten == false && foods[i].isAdded == true) && (foods[i].quality == foodQuality.peekRoot())){
                        preferredFoodIndex = i;
                    }
                }
                for(int i = 0; i < foodCount; i++){
                    if((foods[i].isEaten == false && foods[i].isAdded == true) && (foods[i].quality == foodQuality.peekRoot() && foods[i].id < foods[preferredFoodIndex].id)){
                        preferredFoodIndex = i;
                    }
                }
                preferredFood = foods[preferredFoodIndex];
                if(creatures[i].isAlive && creatures[i].hasEaten == false){
                    double distance = sqrt(pow(abs(creatures[i].x - preferredFood.x), 2.0) + pow(abs(creatures[i].y - preferredFood.y), 2.0));
                    if(distance < 1){
                        creatures[i].hasEaten = true;
                        creatures[i].health += preferredFood.quality;
                        foods[preferredFoodIndex].isEaten = true;
                        currentFoodCount--;
                        int quality;
                        foodQuality.pqDelete(quality);
                    }
                }
            }
            else{
                break;
            }
        }
        if(currentFoodCount != 0){
            int preferredFoodIndex = 0;
            for(int i = 0; i < foodCount; i++){
                if((foods[i].isEaten == false && foods[i].isAdded == true) && (foods[i].quality == foodQuality.peekRoot())){
                    preferredFoodIndex = i;
                }
            }
            for(int i = 0; i < foodCount; i++){
                if((foods[i].isEaten == false && foods[i].isAdded == true) && (foods[i].quality == foodQuality.peekRoot() && foods[i].id < foods[preferredFoodIndex].id)){
                    preferredFoodIndex = i;
                }
            }
            preferredFood = foods[preferredFoodIndex];
            for(int i = 0; i < creatureCount; i++){
                if(creatures[i].isAlive == true){
                    creatures[i].setVelocity();
                    double xDifference = creatures[i].x - preferredFood.x;
                    double yDifference = creatures[i].y - preferredFood.y;
                    double tangent = atan2(yDifference, xDifference);
                    double xChange = abs(creatures[i].velocity * cos(tangent));
                    double yChange = abs(creatures[i].velocity * sin(tangent));
                    if((creatures[i].x - preferredFood.x) > 0){
                        creatures[i].x = creatures[i].x - xChange;
                    }
                    else{
                        creatures[i].x = creatures[i].x + xChange;
                    }
                    if((creatures[i].y - preferredFood.y) > 0){
                        creatures[i].y = creatures[i].y - yChange;
                    }
                    else{
                        creatures[i].y = creatures[i].y + yChange;
                    }
                    creatures[i].health--;
                }
                for(int i = 0; i < creatureCount; i++){
                    if(creatures[i].health == 0){
                        if(creatures[i].isAlive){
                            creatures[i].isAlive = false;
                            deadCreatureCount++;
                        }
                    }
                }
            }
        }
        else{
            for(int i = 0; i < creatureCount; i++){
                if(creatures[i].isAlive == true){
                    creatures[i].health--;
                }
                for(int i = 0; i < creatureCount; i++){
                    if(creatures[i].health == 0){
                        if(creatures[i].isAlive){
                            creatures[i].isAlive = false;
                            deadCreatureCount++;
                        }
                    }
                }
            }
        }
        for(int i = 0; i < creatureCount; i++){
            creatures[i].hasEaten = false;
        }
        timeTick++;
    }
}
