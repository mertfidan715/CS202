/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Header for creature class
*/

class creature{
public:
    creature();
    creature(const int id, const double x, const double y, const int health);
    void setVelocity();
    int id, health;
    double x, y;
    double velocity;
    bool isAlive = true;
    bool hasEaten = false;
};
