#include "food.h"
#include "creature.h"
#include "maxHeapPQ.h"
#include "minHeapPQ.h"
#include <string>
using namespace std;

/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Header for simulation class
*/

class simulation{
public:
    simulation(string inputFileName);
    void startSimulation();
    void sortCreatures(creature creatures[], int size);
private:
    int foodCount = 0, creatureCount = 0, deadCreatureCount = 0, currentFoodCount = 0;
    food foods[1000];
    creature creatures[1000];
    maxHeapPQ foodQuality;
    minHeapPQ foodSpawnTime;
    minHeapPQ creatureIDs;
};
