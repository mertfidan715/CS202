/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Header for food class
*/

class food{
public:
    food();
    food(const int id, const double x, const double y, const int quality, const int spawnTime);
    double x, y;
    int id, quality, spawnTime;
    bool isAdded = false;
    bool isEaten = false;
};
