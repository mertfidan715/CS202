#include "creature.h"

/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Creature class implementation
*/

creature::creature(){
}

creature::creature(const int id, const double x, const double y, const int health){
    this->id = id;
    this->x = x;
    this->y = y;
    this->health = health;
}

void creature::setVelocity(){
    if(health <= 10){
        velocity = 1.0;
    }
    else{
        velocity = 10.0 / health;
    }
}
