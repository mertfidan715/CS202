#include "minHeap.h"

/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Header for Priority Queue class that uses Min Heap
*/

class minHeapPQ{
public:
    bool pqIsEmpty() const;
    void pqInsert(const int& newItem);
    void pqDelete(int& priorityItem);
    int peekRoot();
private:
    minHeap h;
};
