#include "food.h"

/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Food class implementation
*/

food::food(){
}

food::food(const int id, const double x, const double y, const int quality, const int spawnTime){
    this->id = id;
    this->x = x;
    this->y = y;
    this->quality = quality;
    this->spawnTime = spawnTime;
}
