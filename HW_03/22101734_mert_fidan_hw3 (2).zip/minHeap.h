/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Header for Min Heap class
*/

class minHeap{
static const int MAX_HEAP = 10000;
public:
    minHeap(); // default constructor
    // copy constructor and destructor are supplied by the compiler
    bool heapIsEmpty() const;
    void heapInsert(const int& newItem);
    void heapDelete(int& rootItem);
protected:
    void heapRebuild(int root); // Converts the semiheap rooted at
     // index root into a heap
private:
    int items[MAX_HEAP];// array of heap items
    int size; // number of heap items
friend class minHeapPQ;
};
