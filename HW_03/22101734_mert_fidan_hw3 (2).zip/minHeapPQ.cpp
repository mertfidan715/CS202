#include "minHeapPQ.h"

/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Implementation of Priority Queue class that uses Min Heap
*/

bool minHeapPQ::pqIsEmpty() const {
    return h.heapIsEmpty();
}

void minHeapPQ::pqInsert(const int& newItem){
    h.heapInsert(newItem);
}

void minHeapPQ::pqDelete(int& priorityItem){
    h.heapDelete(priorityItem);
}

int minHeapPQ::peekRoot(){
    return h.items[0];
}
