#include "maxHeapPQ.h"

/**
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 3
* Description : Implementation of Priority Queue class that uses Min Heap
*/

bool maxHeapPQ::pqIsEmpty() const {
    return h.heapIsEmpty();
}

void maxHeapPQ::pqInsert(const int& newItem){
    h.heapInsert(newItem);
}

void maxHeapPQ::pqDelete(int& priorityItem){
    h.heapDelete(priorityItem);
}

int maxHeapPQ::peekRoot(){
    return h.items[0];
}
