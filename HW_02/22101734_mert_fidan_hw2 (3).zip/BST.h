#include "BSTNode.h"

/**
* Title: Binary Search Trees
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 2
* Description : BST header
*/

class BST{
public:
    BST();
    BST(int rootItem);
    ~BST();
    bool isEmpty();
    void insertItem(int key);
    void deleteItem(int key);
    int* inorderTraversal(int& length);
    void elementArray(const BSTNode* bst, int* arr, int& index);
    bool hasSequence(int* seq, int length);
    BSTNode* root;
    int itemCount = 0;
private:
    void insertItemRecursive(BSTNode*& treeNode, int key);
    void deleteItemRecursive(BSTNode*& treeNode, int key);
    void hasSequenceRecursive(BSTNode*& treeNode, int* seq, int length, bool& res);
    void inorder(BSTNode*& treeNode, int* arr, int& index);
    void processLeftMost(BSTNode*& treeNode, int& key);
};

BST* merge(const BST& tree1, const BST& tree2);
