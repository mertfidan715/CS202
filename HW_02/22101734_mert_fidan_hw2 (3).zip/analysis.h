#ifndef ANALYSIS_H
#define ANALYSIS_H

/**
* Title: Binary Search Trees
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 2
* Description : Header for timeAnalysis function
*/

void timeAnalysis();
#endif // ANALYSIS_H

