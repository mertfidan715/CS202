#include "BSTNode.h"

/**
* Title: Binary Search Trees
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 2
* Description : Implementation of BSTNode header
*/

BSTNode::BSTNode(){
    item = 0;
    leftChildPtr = nullptr;
    rightChildPtr = nullptr;
}

BSTNode::BSTNode(int& nodeItem, BSTNode* left, BSTNode* right){
    item = nodeItem;
    leftChildPtr = left;
    rightChildPtr = right;
}


