#include "BST.h"
#include <cstddef>
#include <iostream>
using namespace std;

/**
* Title: Binary Search Trees
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 2
* Description : Implementation of BST header
*/

BST::BST(){
    root = nullptr;
    itemCount = 0;
}

BST::BST(int rootItem){
    root = new BSTNode(rootItem, nullptr, nullptr);
    itemCount = 1;
}

BST::~BST(){

}

bool BST::isEmpty(){
    return itemCount == 0;
}

void BST::insertItem(int key){
 insertItemRecursive(root, key);
 itemCount++;
}

void BST::insertItemRecursive(BSTNode*& treeNode, int key){
    if(treeNode == nullptr){
        treeNode = new BSTNode(key, nullptr, nullptr);
    }
    else{
        if(treeNode->item < key){
            insertItemRecursive(treeNode->rightChildPtr, key);
        }
        else{
            insertItemRecursive(treeNode->leftChildPtr, key);
        }
    }
}

void BST::deleteItem(int key){
    deleteItemRecursive(root, key);
    itemCount--;
}

void BST::deleteItemRecursive(BSTNode*& treeNode, int key){
    if(treeNode->item == key){
        BSTNode* delPtr;
        int delItem;
        if((treeNode->rightChildPtr == nullptr) && (treeNode->leftChildPtr == nullptr)){
            delete[] treeNode;
            treeNode = nullptr;
        }
        else if((treeNode->rightChildPtr != nullptr) && (treeNode->leftChildPtr == nullptr)){
            delPtr = treeNode;
            treeNode = treeNode->rightChildPtr;
            delPtr->rightChildPtr = nullptr;
            delete[] delPtr;
        }
        else if((treeNode->rightChildPtr == nullptr) && (treeNode->leftChildPtr != nullptr)){
            delPtr = treeNode;
            treeNode = treeNode->leftChildPtr;
            delPtr->leftChildPtr = nullptr;
            delete[] delPtr;
        }
        else{
            processLeftMost(treeNode->rightChildPtr, delItem);
            treeNode->item = delItem;
        }
    }
    else if(treeNode->item < key){
        deleteItemRecursive(treeNode->rightChildPtr, key);
    }
    else{
        deleteItemRecursive(treeNode->leftChildPtr, key);
    }
}

void BST::processLeftMost(BSTNode*& treeNode, int& key){
    if(treeNode->leftChildPtr == nullptr){
        key = treeNode->item;
        BSTNode* delPtr = treeNode;
        treeNode = treeNode->rightChildPtr;
        delPtr->rightChildPtr = nullptr;
        delete[] delPtr;
    }
    else{
        processLeftMost(treeNode->leftChildPtr, key);
    }
}

int* BST::inorderTraversal(int& length){
    int* arr = new int[itemCount];
    int index = 0;
    inorder(root, arr, index);
    length = itemCount;
    return arr;
}

void BST::inorder(BSTNode*& treeNode, int* arr, int& index){
    if (treeNode != nullptr) {
        inorder(treeNode->leftChildPtr, arr, index);
        arr[index] = treeNode->item;
        index++;
        inorder(treeNode->rightChildPtr, arr, index);
    }
}

bool BST::hasSequence(int* seq, int length){
    bool res;
    hasSequenceRecursive(root, seq, length, res);
    return res;
}

void BST::hasSequenceRecursive(BSTNode*& treeNode, int* seq, int length, bool& res){
    int firstItem = seq[0];
    int lastItem = seq[length-1];
    std::cout << "Current visited node item: " << treeNode->item << std::endl;
    if((lastItem >= treeNode->item) && (firstItem <= treeNode->item)){
        int* compare = new int[length];
        int index = 0;
        inorder(treeNode, compare, index);
        for(int i = 0; i < length; i++){
            if(compare[i] != seq[i]){
                res = false;
            }
            else{
                res = true;
            }
        }
    }
    else if(lastItem < treeNode->item){
        hasSequenceRecursive(treeNode->leftChildPtr, seq, length, res);
    }
    else if(firstItem > treeNode->item){
        hasSequenceRecursive(treeNode->rightChildPtr, seq, length, res);
    }
}

void BST::elementArray(const BSTNode* bst, int* arr, int& index){ //preorder traversal algorithm is used to create an array(arr) of all elements in a tree
    if(bst != nullptr){
        arr[index] = bst->item;
        index++;
        elementArray(bst->leftChildPtr, arr, index);
        elementArray(bst->rightChildPtr, arr, index);
    }
}

BST* merge(const BST& tree1, const BST& tree2){
    BST* res = new BST;
    int length1 = tree1.itemCount, length2 = tree2.itemCount, index1 = 0, index2 = 0;
    int* bst1 = new int[tree1.itemCount];
    int* bst2 = new int[tree2.itemCount];
    res->elementArray(tree1.root, bst1, index1);
    res->elementArray(tree2.root, bst2, index2);
    for(int i = 0; i < length1; i++){
        res->insertItem(bst1[i]);
    }
    for(int i = 0; i < length2; i++){
        res->insertItem(bst2[i]);
    }
    return res;
}
