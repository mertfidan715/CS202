#include "BST.h"
#include "analysis.h"
#include <string>
#include <iostream>
using namespace std;

/**
* Title: Binary Search Trees
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 2
* Description : Creates two BST's, prints their items, tests hasSequence function for the BST's, merges them together and prints items of merged BST, finally calls timeAnalysis() function
*/

int main(){
    BST bst8(8);
    bst8.insertItem(4);
    bst8.insertItem(13);
    bst8.insertItem(3);
    bst8.insertItem(15);
    bst8.insertItem(6);
    bst8.insertItem(5);
    bst8.insertItem(12);
    bst8.insertItem(10);
    bst8.insertItem(14);
    bst8.insertItem(1);
    bst8.insertItem(2);

    std::cout << "BST rooted at 8 has "<< bst8.itemCount << " items" << std::endl << "Items of this BST(Inorder Traversal): ";
    int inorderLength;
    int* inorderTraversal = bst8.inorderTraversal(inorderLength);
    for(int i = 0; i < inorderLength; i++){
        std::cout << inorderTraversal[i] << ", ";
    }
    std::cout << std::endl << std::endl;

    BST bst9;
    bst9.insertItem(9);
    bst9.insertItem(2);
    bst9.insertItem(3);
    bst9.insertItem(5);
    bst9.insertItem(7);
    bst9.insertItem(8);
    bst9.insertItem(10);
    bst9.insertItem(11);
    bst9.insertItem(12);
    bst9.insertItem(16);
    bst9.insertItem(17);
    bst9.insertItem(18);
    bst9.insertItem(19);
    bst9.insertItem(20);
    std::cout << "BST rooted at 9 has "<< bst9.itemCount << " items" << std::endl << "Items of this BST(Inorder Traversal): ";
    int inorderLength2;
    int* inorderTraversal2 = bst9.inorderTraversal(inorderLength2);
    for(int i = 0; i < inorderLength2; i++){
        std::cout << inorderTraversal2[i] << ", ";
    }

    std::cout << std::endl << "\nRunning merge() for BST rooted at 8 and BST rooted at 9:" << std::endl;
    BST* merged = merge(bst8, bst9);
    std::cout << "Merged BST has " << merged->itemCount << " items and it is rooted at " << merged->root->item << std::endl << "Items of this BST(Inorder Traversal): ";
    int inorderLength3;
    int* inorderTraversal3 = merged->inorderTraversal(inorderLength3);
    for(int i = 0; i < inorderLength3; i++){
        std::cout << inorderTraversal3[i] << ", ";
    }
    std::cout << std::endl << std::endl;

    BST bst15(15);
    bst15.insertItem(19);
    bst15.insertItem(21);
    bst15.insertItem(11);
    bst15.insertItem(12);
    bst15.insertItem(9);
    bst15.insertItem(18);
    bst15.insertItem(16);
    bst15.insertItem(25);
    bst15.insertItem(7);
    bst15.insertItem(13);
    bst15.insertItem(8);
    bst15.insertItem(23);
    bst15.insertItem(26);
    bst15.insertItem(10);
    std::cout << "BST rooted at 15 has "<< bst15.itemCount << " items" << std::endl << "Items of this BST(Inorder Traversal): ";
    int inorderLength4;
    int* inorderTraversal4 = bst15.inorderTraversal(inorderLength4);
    for(int i = 0; i < inorderLength4; i++){
        std::cout << inorderTraversal4[i] << ", ";
    }
    std::cout << std::endl << "\nRunning merge() for BST rooted at 9 and BST rooted at 15:" << std::endl;
    BST* merged2 = merge(bst9, bst15);
    std::cout << "Merged BST has " << merged2->itemCount << " items and it is rooted at " << merged2->root->item << std::endl << "Items of this BST(Inorder Traversal): ";
    int inorderLength5;
    int* inorderTraversal5 = merged2->inorderTraversal(inorderLength5);
    for(int i = 0; i < inorderLength5; i++){
        std::cout << inorderTraversal5[i] << ", ";
    }
    std::cout << std::endl;
    bst15.deleteItem(7);
    bst15.deleteItem(25);
    bst15.deleteItem(10);
    bst15.deleteItem(12);
    bst15.deleteItem(15);
    std::cout << std::endl << "After the deletion of 7, 25, 10, 12, 15 from BST15, updated BST15 has " << bst15.itemCount << " items and it is now rooted at " << bst15.root->item <<  std::endl << "Items of this BST(Inorder Traversal): ";
    int inorderLength6;
    int* inorderTraversal6 = bst15.inorderTraversal(inorderLength6);
    for(int i = 0; i < inorderLength6; i++){
        std::cout << inorderTraversal6[i] << ", ";
    }

    int seq1[] = {1, 2, 3, 4};
    int seq2[] = {1, 2, 3, 4, 5, 6};
    int seq3[] = {10, 12, 13, 15};
    int seq4[] = {10, 11, 12};
    int seq5[] = {18, 19, 21, 23};
    int seq6[] = {11, 13, 16};
    int seq7[] = {8, 9, 11, 13, 16};
    int seq8[] = {21, 23, 25, 26};

    std::cout << std::endl << std::endl << "Running hasSequence() tests:" << std::endl << std::endl;
    std::cout << "hasSequence() for BST15 rooted at 16(after deletions) and sequence 18, 19, 21, 23: " << std::endl << std::endl << bst15.hasSequence(seq5, 4) << std::endl << std::endl;
    std::cout << "hasSequence() for BST15 rooted at 16(after deletions) and sequence 11, 13, 16: " << std::endl << std::endl << bst15.hasSequence(seq6, 3) << std::endl << std::endl;
    std::cout << "hasSequence() for BST15 rooted at 16(after deletions) and sequence 8, 9, 11, 13, 16: " << std::endl << std::endl << bst15.hasSequence(seq7, 5) << std::endl << std::endl;
    std::cout << "hasSequence() for BST15 rooted at 16(after deletions) and sequence 21, 23, 25, 26: " << std::endl << std::endl << bst15.hasSequence(seq8, 4) << std::endl << std::endl;
    std::cout << "hasSequence() for BST rooted at 8 and sequence 1, 2, 3, 4: " << std::endl << std::endl << bst8.hasSequence(seq1, 4) << std::endl << std::endl;
    std::cout << "hasSequence() for BST rooted at 8 and sequence 1, 2, 3, 4, 5, 6: " << std::endl << std::endl << bst8.hasSequence(seq2, 6) << std::endl << std::endl;
    std::cout << "hasSequence() for BST rooted at 8 and sequence 10, 12, 13, 15: " << std::endl << std::endl << bst8.hasSequence(seq3, 4) << std::endl << std::endl;
    std::cout << "hasSequence() for BST rooted at 8 and sequence 10, 11, 12,: " << std::endl << std::endl << bst8.hasSequence(seq4, 3) << std::endl << std::endl;

    timeAnalysis();
    return 0;
}
