#include <iostream>
#include <ctime>
#include <math.h>
#include <string>
#include <algorithm>
#include <random>
#include "analysis.h"
#include "BST.h"

/**
* Title: Binary Search Trees
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 2
* Description : Implementation of timeAnalysis function that creates an array of 15.000 random items, insesrts them into a BST, prints out ellapsed time after each 1500 insertion,
*shuffles the array, deletes items and prints elapsed time after each 1500 deletion
*/

void timeAnalysis(){
    BST binarySearchTree;
    int* arr = new int[15000];
    for(int m = 0; m < 15000; m++){
        int n = (rand() % 100000);
        arr[m] = n;
    }
    std::cout << "Part e - Time analysis of Binary Search Tree - part 1" << std::endl << "------------------------------------------------------" << std::endl << "Tree Size                Time Elapsed" << std::endl << "------------------------------------------------------" << std::endl;
    for(int i = 0; i < 10; i++){
        {
            double duration;
            clock_t startTime = clock();
            for(int q = 1500 * i; q < 1500 * (i + 1); q++){
                binarySearchTree.insertItem(arr[q]);
            }
            duration = 1000 * double( clock() - startTime ) / CLOCKS_PER_SEC;
            std::cout.width(25); std::cout << std::left << (i+1)*1500;
            std::cout.width(26);std::cout << std::left << duration;
            std::cout << std::endl;
        }
    }
    unsigned seed = 0;
    std::shuffle(arr, arr + 15000, std::default_random_engine(seed));
    std::cout << std::endl << "Part e - Time analysis of Binary Search Tree - part 2" << std::endl << "------------------------------------------------------" << std::endl << "Tree Size                Time Elapsed" << std::endl << "------------------------------------------------------" << std::endl;
    for(int i = 0; i < 10; i++){
        {
            double duration;
            clock_t startTime = clock();
            for(int q = 1500 * i; q < 1500 * (i + 1); q++){
                binarySearchTree.deleteItem(arr[q]);
            }
            duration = 1000 * double( clock() - startTime ) / CLOCKS_PER_SEC;
            std::cout.width(25); std::cout << std::left << 15000 - ((i+1) * 1500);
            std::cout.width(26);std::cout << std::left << duration;
            std::cout << std::endl;
        }
    }
    delete[] arr;
}
