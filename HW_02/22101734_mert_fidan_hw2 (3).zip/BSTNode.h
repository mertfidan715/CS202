#ifndef BSTNODE_H
#define BSTNODE_H

/**
* Title: Binary Search Trees
* Author : Mert Fidan
* ID: 22101734
* Section : 2
* Homework : 2
* Description : BSTNode header
*/

class BSTNode{
public:
    BSTNode();
    BSTNode(int& nodeItem, BSTNode* left, BSTNode* right);
    int item;
    BSTNode* leftChildPtr;
    BSTNode* rightChildPtr;
    friend class BST;
};
#endif
